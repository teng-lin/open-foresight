import json,re,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
root=Path('/tmp/ofs-acceptance-history-20261020')
runs={r['id']:r for r in json.loads((root/'all-runs.json').read_text())}
failed=json.loads((root/'failed-jobs.json').read_text())
ansi=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
def text(job):return ansi.sub('',(root/'logs'/f"{job['id']}.txt").read_text(errors='replace'))
def checkout(value):
 rows=value.splitlines()
 for n,line in enumerate(rows):
  if 'git log -1 --format=%H' in line and n+1<len(rows):
   match=re.search(r' ([0-9a-f]{40})\s*$',rows[n+1])
   if match:return match[1]
 return None
records=[]
for rid in sorted({r['run_id'] for r in failed}):
 run=runs[rid]
 if run['event']!='pull_request':continue
 jobs=[j for p in json.loads((root/'jobs'/f'{rid}.json').read_text()) for j in p['jobs']]
 changes=[j for j in jobs if j['name']=='changes' and (root/'logs'/f"{j['id']}.txt").exists()]
 evidence=None
 for job in changes:
  value=text(job);bases=re.findall(r'\bBASE: ([0-9a-f]{40})',value)
  if bases and checkout(value):
   evidence={'run_id':rid,'job_id':job['id'],'attempt':job['run_attempt'],'source':checkout(value),'head':run['head_sha'],'base':bases[-1],'kind':'original-changes-environment'};break
 if evidence is None:
  for job in jobs:
   if not (root/'logs'/f"{job['id']}.txt").exists():continue
   value=text(job);merge=re.findall(r'HEAD is now at \w+ Merge ([0-9a-f]{40}) into ([0-9a-f]{40})',value)
   if merge and checkout(value):
    head,base=merge[0]
    if head!=run['head_sha']:raise RuntimeError('Wrong mergehead')
    evidence={'run_id':rid,'job_id':job['id'],'attempt':job['run_attempt'],'source':checkout(value),'head':head,'base':base,'kind':'original-merge-checkout'};break
 if evidence is None:evidence={'run_id':rid,'unresolved':'Original event base not recovered'}
 records.append(evidence)
print('RANGES',len(records),'UNRESOLVED',[r for r in records if 'unresolved' in r],flush=True)
(root/'ranges.json').write_text(json.dumps(records,indent=2)+'\n')
def fetch(record):
 if 'unresolved' in record:return
 route=f"compare/{record['base']}...{record['source']}"
 path=root/'compares'/f"{record['base']}-{record['source']}.json"
 if path.exists():return
 path.parent.mkdir(exist_ok=True)
 for attempt in range(3):
  result=subprocess.run(['gh','api',f'repos/teng-lin/open-foresight/{route}'],capture_output=True,text=True,timeout=300)
  if not result.returncode:break
  if attempt==2:raise RuntimeError(route+result.stderr)
 path.write_text(result.stdout)
with ThreadPoolExecutor(max_workers=8) as workers:list(workers.map(fetch,records))
print('COMPARES',len(list((root/'compares').glob('*.json'))),flush=True)
