from concurrent.futures import ThreadPoolExecutor
from datetime import date,timedelta,datetime,timezone
import json,subprocess
from pathlib import Path
root=Path('/tmp/ofs-acceptance-history-20261020')
repo='teng-lin/open-foresight'
def fetch(route,destination):
    if destination.exists():return json.loads(destination.read_text())
    for attempt in range(3):
        result=subprocess.run(['gh','api','--paginate','--slurp',f'repos/{repo}/{route}'],capture_output=True,text=True,timeout=300)
        if not result.returncode:break
        if attempt==2:raise RuntimeError(route+': '+result.stderr)
    value=json.loads(result.stdout)
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_text(json.dumps(value,indent=2)+'\n')
    return value
start=date(2026,10,12)
end=date(2026,10,21)
def day(value):
    rows=fetch('actions/runs?created='+value.isoformat()+'&per_page=100',root/'days'/f'{value}.json')
    actual=[r for p in rows for r in p['workflow_runs']]
    if len(actual)>=1000:
        actual=[]
        for hour in range(0,24,6):
            boundary=f'{value}T{hour:02}:00:00Z..{value}T{hour+5:02}:59:59Z'
            chunks=fetch('actions/runs?created='+boundary+'&per_page=100',root/'days'/f'{value}-{hour}.json')
            part=[r for p in chunks for r in p['workflow_runs']]
            if len(part)>=1000 or chunks[0]['total_count']!=len(part):raise RuntimeError('Incomplete chunk '+boundary)
            actual.extend(part)
    if rows[0]['total_count']!=len({r['id'] for r in actual}):raise RuntimeError('Incomplete day '+str(value))
    return actual
with ThreadPoolExecutor(max_workers=6) as workers:
    batches=list(workers.map(day,[start+timedelta(days=i) for i in range((end-start).days+1)]))
runs={r['id']:r for batch in batches for r in batch}
(root/'all-runs.json').write_text(json.dumps(list(runs.values()),indent=2)+'\n')
print('RUNS',len(runs),flush=True)
from collections import Counter
print(Counter(r['path'] for r in runs.values()),flush=True)
paths={'.github/workflows/macos.yml','.github/workflows/integration-acceptance.yml','.github/workflows/release-acceptance.yml','.github/workflows/release.yml','.github/workflows/preview-packages.yml','.github/workflows/linux-packages.yml','.github/workflows/macos-release.yml'}
selected=[run for run in runs.values() if run['path'] in paths]
def get_jobs(run):
    pages=fetch(f"actions/runs/{run['id']}/jobs?filter=all&per_page=100",root/'jobs'/f"{run['id']}.json")
    jobs=[job for page in pages for job in page['jobs']]
    attempts={job.get('run_attempt') for job in jobs}
    if jobs and any(not isinstance(attempt,int) or attempt<1 or attempt>run['run_attempt'] for attempt in attempts):raise RuntimeError('Wrong original attempt')
    return len(jobs)
with ThreadPoolExecutor(max_workers=10) as workers:
    counts=list(workers.map(get_jobs,selected))
print('JOBS',len(selected),sum(counts),flush=True)
