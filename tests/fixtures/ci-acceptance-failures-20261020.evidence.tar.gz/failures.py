from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json,subprocess
root=Path('/tmp/ofs-acceptance-history-20261020')
rows=json.loads((root/'failed-jobs.json').read_text())
runs={r['id']:r for r in json.loads((root/'all-runs.json').read_text())}
def get_log(row):
 path=root/'logs'/f"{row['job_id']}.txt"
 if path.exists():return
 path.parent.mkdir(exist_ok=True)
 result=subprocess.run(['gh','api','--allow-escape-sequences',f"repos/teng-lin/open-foresight/actions/jobs/{row['job_id']}/logs"],capture_output=True,timeout=300)
 if result.returncode:raise RuntimeError(str(row['job_id'])+': '+result.stderr.decode())
 path.write_bytes(result.stdout)
def get_pr(source):
 path=root/'associations'/f'{source}.json'
 if path.exists():return
 path.parent.mkdir(exist_ok=True)
 result=subprocess.run(['gh','api','--paginate','--slurp',f'repos/teng-lin/open-foresight/commits/{source}/pulls?per_page=100'],capture_output=True,timeout=300)
 if result.returncode:raise RuntimeError(source+': '+result.stderr.decode())
 path.write_bytes(result.stdout)
with ThreadPoolExecutor(max_workers=10) as workers:list(workers.map(get_log,rows))
print('LOGS',len(rows),flush=True)
with ThreadPoolExecutor(max_workers=10) as workers:list(workers.map(get_pr,{row['head_sha'] for row in rows if row['event']=='pull_request'}))
print('PRS',len(list((root/'associations').glob('*.json'))),flush=True)
