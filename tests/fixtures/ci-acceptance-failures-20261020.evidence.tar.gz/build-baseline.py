from pathlib import Path
import json,hashlib,re,sys,tarfile,io,gzip
root=Path('/tmp/ofs-acceptance-history-20261020')
repo=Path('/home/blackmyth/src/open-foresight-ci-acceptance-proof')
sys.path.insert(0,str(repo))
from tools.ci_acceptance_plan import plan,PHASES
runs=json.loads((root/'all-runs.json').read_text()); runmap={r['id']:r for r in runs}
candidate_paths={'.github/workflows/macos.yml','.github/workflows/integration-acceptance.yml','.github/workflows/release-acceptance.yml','.github/workflows/release.yml','.github/workflows/preview-packages.yml','.github/workflows/linux-packages.yml','.github/workflows/macos-release.yml'}
ranges={r['run_id']:r for r in json.loads((root/'ranges.json').read_text())}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def checkout(text):
 lines=text.splitlines()
 for n,line in enumerate(lines):
  if 'git log -1 --format=%H' in line and n+1<len(lines):
   m=re.search(r' ([a-f0-9]{40})\s*$',lines[n+1])
   if m:return m[1]
 return None
failures=[];jobs_count=0;candidate_runs=[];missing_logs=[]
for run in runs:
 if run['path'] not in candidate_paths:continue
 candidate_runs.append({k:run.get(k) for k in ('id','path','event','head_sha','head_branch','run_attempt','status','conclusion')})
 jobfile=root/'jobs'/f"{run['id']}.json"
 jobs=[j for p in json.loads(jobfile.read_text()) for j in p['jobs']];jobs_count+=len(jobs)
 acceptance_workflow='acceptance' in run['path'] or run['path'].endswith('preview-packages.yml')
 failed=[]
 for job in jobs:
  if run['path'].endswith('/macos.yml') and not any(x in job['name'].lower() for x in ('acceptance','audit')):continue
  steps=[s for s in job.get('steps',[]) if s.get('conclusion') in ('failure','timed_out','startup_failure')]
  if job.get('conclusion') not in ('failure','timed_out','startup_failure') and not steps:continue
  failed.append((job,steps))
 if run['conclusion']=='startup_failure' and not any(j.get('run_attempt')==run['run_attempt'] for j in jobs):
  failed.append(({'id':0,'run_attempt':run['run_attempt'],'name':'workflow startup','conclusion':'startup_failure'},[]))
 for job,steps in failed:
  logpath=root/'logs'/f"{job['id']}.txt"
  unavailable=root/'logs'/f"{job['id']}.unavailable.json"
  if job['id'] and not logpath.exists() and not unavailable.exists():missing_logs.append(job['id']);continue
  content=logpath.read_text(errors='replace') if logpath.exists() else ''
  evidence=[{'path':jobfile.relative_to(root).as_posix(),'sha256':sha(jobfile)}]
  if logpath.exists():evidence.append({'path':logpath.relative_to(root).as_posix(),'sha256':sha(logpath)})
  elif unavailable.exists():evidence.append({'path':unavailable.relative_to(root).as_posix(),'sha256':sha(unavailable)})
  source=checkout(content) or run['head_sha']
  record={'id':f"{run['id']}:{job['run_attempt']}:{job['id']}",'run':run['id'],'attempt':job['run_attempt'],'job':job['id'],'job_name':job['name'],'event':run['event'],'head':run['head_sha'],'source':source,'branch':run['head_branch'],'conclusion':job['conclusion'],'failed_steps':steps,'evidence':evidence,'force_full':False}
  if job['id']==0:
   runproof=root/'startup'/'run.json';jobproof=root/'startup'/'jobs.json';actualrun=json.loads(runproof.read_text());actualjobs=json.loads(jobproof.read_text())
   assert actualrun['id']==run['id'] and actualrun['run_attempt']==job['run_attempt'] and actualrun['conclusion']=='startup_failure'
   assert actualjobs['total_count']==0 and actualjobs['jobs']==[]
   record.update(source=run['head_sha'],paths=[],range={'kind':'workflow-startup-no-jobs'},required_phases=[],classification='workflow-startup-no-jobs',startup_proof={'run':run['id'],'attempt':job['run_attempt'],'conclusion':'startup_failure','status':'completed','job_count':0,'workflow':run['path']})
   evidence.extend([{'path':f.relative_to(root).as_posix(),'sha256':sha(f)} for f in (runproof,jobproof)])
   failures.append(record);continue
  if run['event']=='pull_request':
   scope=ranges[run['id']];source=scope['source'];base=scope['base'];cmpfile=root/'compares'/f'{base}-{source}.json';comp=json.loads(cmpfile.read_text())
   if len(comp['files'])>=300:raise RuntimeError('Incomplete compare')
   if comp['base_commit']['sha']!=base or (comp['commits'] and comp['commits'][-1]['sha']!=source):raise RuntimeError('Incorrect compare source')
   pathlist=sorted({name for f in comp['files'] for name in (f['filename'],f.get('previous_filename')) if name})
   prooflog=root/'logs'/f"{scope['job_id']}.txt"
   record.update(source=source,paths=pathlist,range={'base':base,'head':source,'merge_base':comp['merge_base_commit']['sha'],'proof_job':scope['job_id'],'proof_attempt':scope['attempt'],'kind':scope['kind'],'file_count':len(comp['files'])})
   evidence.extend([{'path':cmpfile.relative_to(root).as_posix(),'sha256':sha(cmpfile)},{'path':prooflog.relative_to(root).as_posix(),'sha256':sha(prooflog)}])
   assoc=root/'associations'/f"{run['head_sha']}.json"
   if assoc.exists():
    prs=[p for page in json.loads(assoc.read_text()) for p in page]
    record['pull_requests']=[p['number'] for p in prs if p['head']['ref']==run['head_branch']]
  else:record.update(paths=[],range={'kind':'full-event-backstop'})
  phases=set()
  for step in steps:
   name=step['name'].lower()
   if 'cpu model' in name or 'model, helper' in name:phases.add('cpu-models')
   elif 'gpu' in name and ('software' in name or 'vulkan' in name):phases.add('software-gpu')
   elif 'virtual-audio' in name or 'virtual audio' in name:phases.add('virtual-audio')
   else:phases.update(PHASES)
  if not logpath.exists():phases=set(PHASES)
  record['classification']='identified-phase' if phases and phases!=set(PHASES) else 'conservative-prerequisite-or-aggregate'
  record['required_phases']=sorted(phases or PHASES)
  failures.append(record)
if missing_logs:raise RuntimeError('Missing logs: '+str(missing_logs))
failures.sort(key=lambda f:(f['run'],f['attempt'],f['job']))
misses=[]
for f in failures:
 selected=plan(f['paths'],f['event'])['proposed']
 missing=[p for p in f['required_phases'] if not selected[p]]
 if missing:misses.append((f['id'],f.get('pull_requests'),missing,f['paths']))
print('CANDIDATES',len(candidate_runs),'JOBS',jobs_count,'FAILURES',len(failures),'MISSES',len(misses),flush=True)
for row in misses:print('MISS',row,flush=True)
value={'schema':1,'repository':'teng-lin/open-foresight','since':'2026-10-12T00:00:00Z','until':'2026-10-21T00:04:53Z','complete':True,'collection':{'runs_discovered':len(runs),'candidate_runs':len(candidate_runs),'jobs':jobs_count,'pagination':'all pages; subdaily windows below 1000; jobs filter=all original attempts','candidate_workflows':sorted(candidate_paths)},'runs':candidate_runs,'failures':failures}
(root/'inventory.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
