import json,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
root=Path('/tmp/ofs-acceptance-history-20261020');failures=json.loads((root/'failed-jobs.json').read_text())
ids={r['run_id'] for r in failures if r['event']=='pull_request'}
rows=[]
for identity in ids:
 for page in json.loads((root/'jobs'/f'{identity}.json').read_text()):
  for job in page['jobs']:
   if job['name'] in ('changes','plan'):
    rows.append(job)
def fetch(job):
 path=root/'logs'/f"{job['id']}.txt"
 if path.exists():return
 result=subprocess.run(['gh','api','--allow-escape-sequences',f"repos/teng-lin/open-foresight/actions/jobs/{job['id']}/logs"],capture_output=True,timeout=300)
 if result.returncode:raise RuntimeError(str(job['id'])+result.stderr.decode())
 path.write_bytes(result.stdout)
with ThreadPoolExecutor(max_workers=8) as workers:list(workers.map(fetch,rows))
print('CHANGES LOGS',len(rows))
